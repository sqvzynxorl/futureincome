# FutureIncome / ContentForge AI

A minimal Next.js AI marketing content generator.

## Deploy

1. Upload all files to GitHub.
2. Connect the repository to Vercel.
3. Optional: add `OPENAI_API_KEY` in Vercel Environment Variables for real AI output.

Without an API key, the app returns demo content so the website still works.
