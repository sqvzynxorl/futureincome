import "./globals.css"
import type { Metadata } from "next"

export const metadata: Metadata = {
  title: "ContentForge AI",
  description: "AI marketing content generator",
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
