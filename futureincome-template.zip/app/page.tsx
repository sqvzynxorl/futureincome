"use client"

import { useState } from "react"

const templates = [
  "TikTok Ad Copy",
  "Instagram Caption",
  "Product Description",
  "Email Marketing",
  "SEO Blog Intro",
  "Sales Page Headline",
]

const features = [
  ["TikTok Ads", "Create short-form video scripts that convert viewers into customers."],
  ["Instagram Captions", "Generate engaging captions and hashtag ideas for your posts."],
  ["Product Copy", "Write product descriptions that highlight benefits and drive sales."],
  ["Email Campaigns", "Create persuasive emails for launches, promos, and follow-ups."],
  ["SEO Intros", "Generate blog introductions optimized for search and readability."],
  ["Sales Headlines", "Create strong landing page headlines and calls to action."],
]

const plans = [
  ["Starter", "£12", "100 AI generations"],
  ["Creator", "£29", "Unlimited generations"],
  ["Agency", "£79", "Client-ready exports"],
]

export default function Page() {
  const [prompt, setPrompt] = useState("")
  const [template, setTemplate] = useState("TikTok Ad Copy")
  const [result, setResult] = useState("")
  const [loading, setLoading] = useState(false)

  async function generateContent() {
    if (!prompt.trim()) return

    setLoading(true)
    setResult("")

    try {
      const res = await fetch("/api/generate", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ prompt, template }),
      })

      const data = await res.json()
      setResult(data.content || data.error || "No content generated.")
    } catch {
      setResult("Error generating content. Please try again.")
    } finally {
      setLoading(false)
    }
  }

  return (
    <main className="site">
      <header className="header">
        <div className="navWrap">
          <a href="#" className="brand">ContentForge AI</a>
          <nav className="nav">
            <a href="#generator">Generator</a>
            <a href="#features">Features</a>
            <a href="#pricing">Pricing</a>
          </nav>
          <a href="#generator" className="smallButton">Sign In</a>
        </div>
      </header>

      <section className="hero">
        <span className="pill">AI Marketing Tool</span>
        <h1>Create Marketing Content with AI</h1>
        <p>Generate ads, captions, product descriptions, emails, and sales copy in seconds.</p>
        <div className="actions">
          <a href="#generator" className="primaryLink">Start Free Trial</a>
          <a href="#features" className="secondaryLink">View Demo</a>
        </div>
      </section>

      <section id="generator" className="section">
        <div className="panel">
          <h2>AI Content Generator</h2>
          <p className="muted">Choose a template, enter your idea, and generate content.</p>

          <div className="templateGrid">
            {templates.map((item) => (
              <button
                key={item}
                type="button"
                onClick={() => setTemplate(item)}
                className={template === item ? "template active" : "template"}
              >
                {item}
              </button>
            ))}
          </div>

          <textarea
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Example: Create a TikTok ad for a fitness app..."
          />

          <button
            type="button"
            onClick={generateContent}
            disabled={loading || !prompt.trim()}
            className="generateButton"
          >
            {loading ? "Generating..." : "Generate with AI"}
          </button>

          {result && (
            <div className="result">
              <h3>AI Generated Content</h3>
              <p>{result}</p>
            </div>
          )}
        </div>
      </section>

      <section id="features" className="section">
        <h2 className="centerTitle">Features</h2>
        <div className="cards">
          {features.map(([title, desc]) => (
            <div className="card" key={title}>
              <h3>{title}</h3>
              <p>{desc}</p>
            </div>
          ))}
        </div>
      </section>

      <section id="pricing" className="section">
        <h2 className="centerTitle">Pricing</h2>
        <div className="cards three">
          {plans.map(([name, price, desc]) => (
            <div className="card" key={name}>
              <h3>{name}</h3>
              <div className="price">{price}<span>/mo</span></div>
              <p>{desc}</p>
              <a href="#generator" className="planButton">Choose Plan</a>
            </div>
          ))}
        </div>
      </section>

      <footer className="footer">© 2026 ContentForge AI</footer>
    </main>
  )
}
